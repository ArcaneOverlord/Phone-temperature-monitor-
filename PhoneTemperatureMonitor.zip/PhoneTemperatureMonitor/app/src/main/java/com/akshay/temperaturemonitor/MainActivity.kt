
package com.akshay.temperaturemonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.akshay.temperaturemonitor.ui.theme.PhoneTemperatureMonitorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PhoneTemperatureMonitorTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Phone Temperature: 32°C")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Cooling Tips: Keep away from sunlight")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Temperature History: 30°C, 31°C, 32°C")
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Temperature Guide: 30-40°C is normal")
                    }
                }
            }
        }
    }
}
